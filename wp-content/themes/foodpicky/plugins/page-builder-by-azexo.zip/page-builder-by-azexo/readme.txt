=== Page Builder by AZEXO ===
Contributors: azexo
Tags: visual editor, grid builder, slider builder, wysiwyg, website builder, landing page builder, front-end builder, drag-and-drop, builder, editor, azexo, landing page, page builder, form builder, form, carousel, masonry, gallery, hover effects, table, parallax
Requires at least: 4.4
Tested up to: 4.9
Stable tag: 1.27
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Frontend drag & drop page builder for layouts any complexity.


== Description ==

Any design fast building without coding.


= Main features =

- CSS styles - fast editing.
- Responsive design - fast editing.
- Unlimited nested layouts.
- Parallax background.
- Video background.
- Gradient background.
- WordPress Widgets - supported.
- Any masonry grid layouts - fast building.
- Any slider layouts - fast building.
- Contact form - fast building with any layout.
- Anchors menu - fast building.
- Sticky header - fast building with any layout.
- Classic table - fast building with any contents.
- Hover overlay - fast building with any layout and with animations.
- Modal dialog - fast building with any layout.
- Custom layers - for backgrounds or overlays.
- Scroll animation - simple and flexible.
- Blank Page Template - with header and footer possibility.


== Installation ==

1. Upload the `azexo_html` folder to your plugins directory (e.g. `/wp-content/plugins/`)
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Follow the instructions

== Frequently Asked Questions ==

= Why are there no FAQs besides this one? =

Because you haven't asked one yet.


== Changelog ==

= 1.27 =
* Initial Release
